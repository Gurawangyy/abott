exports.paymentstore = (owner) => {
return `*PAYMENT STORE*
Dana : 0881-7864-684
Ovo : 0823-1646-4080
Pulsa : 0823-1646-4080

Note :
Jika Sudah Transfer Wajib Kirim
Bukti Transfer Ke Nomor Di Bawah
Agar Bisa Cepat Di Proses Langsung

Wa.me/${owner}
`
}

exports.diamondFF = () => {
return`*DROP DATA DIAMOND FF*
• VIA ID
• LEGAL 100%
• PROSES 1-7 MENIT

*50 💎 Rp 7.789*
*70 💎 Rp 10.000*
*100 💎 Rp 15.500*
*140 💎 Rp 19.500*
*210 💎 Rp 28.522*
*355 💎 Rp 46.500*
*500 💎 Rp 66.500*
*720 💎 Rp 92.740*
*1000 💎 Rp 129.104*
*1440 💎 Rp 183.200*
*2000 💎 Rp 250.400*

*Member Mingguan Rp 28.800*
*Member Bulanan Rp 138.000*

Note : 
• Harga sewaktu waktu berubah
• Pastikan ID Sudah benar
• Pemesanan lebih tinggal x kan saja
• Kesalahan Pengirim data tidak ada reff
`
}

exports.hagostore = () => {
return `*DROP DATA DIAMOND HAGO*
• VIA ID
• LEGAL 100%
• PROSES 1-3 MENIT

*6 💎 Rp 2.000*
*45 💎 Rp 15.000*
*90 💎 Rp 30.000*
*225 💎 Rp 74.000*
*375 💎 Rp 121.000*
*900 💎 Rp 291.000*
*1650 💎 Rp 531.000*

Note : 
• Harga sewaktu waktu berubah
• Pastikan ID Sudah benar
• Pemesanan lebih tinggal x kan saja
• Kesalahan Pengirim data tidak ada reff
`
}

exports.chipstore = () => {
return `Note : 
• Harga sewaktu waktu berubah
• Pastikan ID & Server Sudah benar
• Pemesanan lebih tinggal x kan saja
• Kesalahan Pengirim data tidak ada reff

*DROP DATA CHIP*
• VIA ID + NICK
• LEGAL 100%
• PROSES 1-5 MENIT
• STOK UNLIMITED

*30M Koin Emas-D Rp 6.000*
*60M Koin Emas-D Rp 12.000*
*90M Koin Emas-D Rp 18.000*
*100M Koin Emas-D Rp 19.500*
*200M Koin Emas-D Rp 31.000*
*400M Koin Emas-D Rp 62.000*
*430M Koin Emas-D Rp 68.000*
*500M Koin Emas-D Rp 81.500*
*2B Koin Emas-D Rp 251.000*
*4B Koin Emas-D Rp 502.000*
*6B Koin Emas-D Rp 753.000*
*8B Koin Emas-D Rp 1.004.000*
*10B Koin Emas-D Rp 1.255.000*
*12B Koin Emas-D Rp 1.506.000*
*14B Koin Emas-D Rp 1.757.000*

Note : 
• Harga sewaktu waktu berubah
• Pastikan ID Sudah benar
• Pemesanan lebih tinggal x kan saja
• Kesalahan Pengirim data tidak ada reff
`
}

exports.diamondML = () => {
return `*DROP DATA DIAMOND ML*
• VIA ID & SERVER
• LEGAL 100%
• PROSES 1-5 MENIT

*86 💎 Rp 20.000*
*172 💎 Rp 39.500*
*257 💎 Rp 58.000*
*344 💎 Rp 78.000*
*429 💎 Rp 97.500*
*514 💎 Rp 116.000*
*600 💎 Rp 135.400*
*706 💎 Rp 156.614*
*878 💎 Rp 194.282*
*963 💎 Rp 213.897*
*1412 💎 Rp 310.756*
*2195 💎 Rp 455.170*
*3688 💎 Rp 760.000*
*4394 💎 Rp 890.982*
*5532 💎 Rp 1.145.000*
*9288 💎 Rp 1.901.000*

*Starlight Membership Bonus 12 💎 Rp 97.000*
*Twilight Pass [PROMO ]  Rp 97.000*
*Starlight Membership  Rp 127.000*
*Twilight  Rp 127.000*
*Starlight Membership Plus [PROMO ] Rp 200.000*
*Mobile Legend Member Plus Rp 285.000*
`
}

exports.garenashell = () => {
return `*DROP DATA GARENA SHELL*
• VIA ID
• LEGAL 100%
• PROSES 1-5 MENIT
• STOK UNLIMITED

*33 SHELL 💰	Rp 10.000*
*66 SHELL 💰	Rp 20.000*
*99 SHELL 💰	Rp 30.000*
*165 SHELL 💰	Rp 50.000*
*330 SHELL 💰	Rp 100.000*

Note : 
• Harga sewaktu waktu berubah
• Pastikan ID Sudah benar
• Pemesanan lebih tinggal x kan saja
• Kesalahan Pengirim data tidak ada reff
`
}

exports.cbcashstore = () => {
return `*DROP DATA POINT BLANK*
• VIA ID
• LEGAL 100%
• PROSES 1-5 MENIT
• STOK UNLIMITED

*1200 PB CASH 💸	Rp 10.000*
*2400 PB CASH 💸	Rp 20.000*
*6000 PB CASH 💸	Rp 50.000*
*12000 PB CASH 💸	Rp 95.000*
*24000 PB CASH 💸	Rp 200.000*
*36000 PB CASH 💸	Rp 280.000*
*60000 PB CASH 💸	Rp 480.000*
Note : 
• Harga sewaktu waktu berubah
• Pastikan ID Sudah benar
• Pemesanan lebih tinggal x kan saja
• Kesalahan Pengirim data tidak ada reff
`
}

exports.codmstore = () => {
return `*DROP DATA CALL OF DUTY*
• VIA ID
• LEGAL 100%
• PROSES 1-5 MENIT
• STOK UNLIMITED

*31 CP 💸	Rp 5.000*
*62 CP 💸	Rp 10.000*
*127 CP 💸	Rp 20.000*
*317 CP 💸  Rp 50.000*
*634 CP 💸  Rp 90.000*
*1373 CP 💸 Rp 195.000*
*1901 CP 💸 Rp 250.000*
*3300 CP 💸 Rp 395.000*

Note : 
• Harga sewaktu waktu berubah
• Pastikan ID Sudah benar
• Pemesanan lebih tinggal x kan saja
• Kesalahan Pengirim data tidak ada reff
`
}

exports.pubgstore = () => {
return `*DROP DATA UC PUBG*
• VIA ID
• LEGAL 100%
• PROSES 1-5 MENIT
• STOK UNLIMITED

*53 💸	Rp 10.000*
*105 💸	Rp 22.000*
*131 💸	Rp 29.000*
*263 💸	Rp 48.500*
*530 💸	Rp 96.000*
*825 💸	Rp 143.000*
*1100 💸Rp 187.000*
*1925 💸Rp 319.430*
*2200 💸Rp 372.680*
*2463 💸 Rp 422.230*
*2730 💸 Rp 456.180*
*3025 💸 Rp 502.205*
*3300 💸 Rp 552.205*
*3563 💸 Rp 602.680*
*3830 💸 Rp 632.180*
*4125 💸 Rp 687.180*
*4400 💸 Rp 732.180*
*4663 💸 Rp 776.000*

Note : 
• Harga sewaktu waktu berubah
• Pastikan ID Sudah benar
• Pemesanan lebih tinggal x kan saja
• Kesalahan Pengirim data tidak ada reff
`
}
exports.donasi = () => { 
return`*HAI KAK MAU BENERAN DONASI ATAU TIDAK KAK*
*SEMOGA TIDAK DILIHAT DOANG*

*PAYMENT BOT*
DANA: (0857-8900-4732)
OVO: (0822-7991-5237)
PULSA: (0822-7991-5237)

*TERIMA KASIH KAK*
*LOVE YOU😋*`
}